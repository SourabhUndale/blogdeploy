import React from "react";
import SideBar from "./components/navbar/SideBar";

function Layout() {
  return (
    <>
      <SideBar />
    </>
  );
}

export default Layout;

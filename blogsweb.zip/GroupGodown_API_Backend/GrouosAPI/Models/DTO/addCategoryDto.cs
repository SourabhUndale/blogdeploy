﻿namespace GrouosAPI.Models.DTO
{
    public class addCategoryDto
    {
        public string name { get; set; }
    }
}

﻿namespace GrouosAPI.Models.DTO
{
    public class addApplicationDto
    {
        public string name { get; set; }
    }
}

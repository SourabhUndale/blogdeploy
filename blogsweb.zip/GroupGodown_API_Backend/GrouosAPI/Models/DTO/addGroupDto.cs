﻿namespace GrouosAPI.Models.DTO
{
    public class addGroupDto
    {
      //public string groupName { get; set; }
        public string groupLink { get; set; }
        public string country { get; set; }
        public string Language { get; set; }
        public string? groupDesc { get; set; }
        public string? groupRules { get; set; }
        public string? tags { get; set; }
    }
}

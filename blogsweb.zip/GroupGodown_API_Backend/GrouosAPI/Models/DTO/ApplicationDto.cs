﻿namespace GrouosAPI.Models.DTO
{
    public class ApplicationDto
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
